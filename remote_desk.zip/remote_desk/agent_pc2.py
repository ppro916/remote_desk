import socketio
import base64
import mss
from PIL import Image
import io
import time
import threading
import sys

# Initialize Socket.IO client
sio = socketio.Client()
streaming = False
fps = 6  # Default FPS
jpeg_quality = 60  # Default JPEG quality

def capture_screen():
    """Capture screen and send as base64 JPEG"""
    with mss.mss() as sct:
        # Capture primary monitor
        monitor = sct.monitors[1]
        
        while streaming:
            start_time = time.time()
            
            try:
                # Capture screen
                screenshot = sct.grab(monitor)
                
                # Convert to PIL Image
                img = Image.frombytes('RGB', (screenshot.width, screenshot.height), screenshot.rgb)
                
                # Convert to JPEG
                buffer = io.BytesIO()
                img.save(buffer, format='JPEG', quality=jpeg_quality)
                buffer.seek(0)
                
                # Encode as base64
                img_str = base64.b64encode(buffer.read()).decode('utf-8')
                
                # Send via Socket.IO
                sio.emit('frame', {'frame': img_str})
                
                # Maintain FPS
                elapsed = time.time() - start_time
                sleep_time = max(0, 1/fps - elapsed)
                time.sleep(sleep_time)
                
            except Exception as e:
                print(f"Capture error: {e}")
                time.sleep(1/fps)  # Maintain timing even on error

@sio.event
def connect():
    print("Connected to server")
    sio.emit('identify', {'role': 'agent'})

@sio.event
def disconnect():
    print("Disconnected from server")
    global streaming
    streaming = False

@sio.event
def session_request(data):
    """Handle session request from viewer"""
    viewer_id = data.get('viewer_id')
    print(f"\nSession requested by viewer: {viewer_id}")
    
    # Ask for user confirmation
    response = input("Accept this session? (y/n): ").lower().strip()
    
    if response == 'y' or response == 'yes':
        print("Session accepted. Starting streaming...")
        sio.emit('session_response', {
            'accepted': True,
            'viewer_id': viewer_id
        })
    else:
        print("Session rejected.")
        sio.emit('session_response', {
            'accepted': False,
            'viewer_id': viewer_id
        })

@sio.event
def start_streaming():
    """Start streaming screens to server"""
    global streaming
    if not streaming:
        streaming = True
        # Start capture in a separate thread
        thread = threading.Thread(target=capture_screen)
        thread.daemon = True
        thread.start()
        print("Screen sharing started")

if __name__ == '__main__':
    if len(sys.argv) > 1:
        server_url = sys.argv[1]
    else:
        server_url = 'http://localhost:5000'
    
    try:
        sio.connect(server_url)
        print(f"Connected to {server_url}. Waiting for session requests...")
        sio.wait()
    except Exception as e:
        print(f"Connection error: {e}")
    finally:
        streaming = False
