# Remote Desk - Step 1: Screen Sharing

A lightweight remote screen sharing prototype using Flask-SocketIO.

## Installation

### Termux (Android Server)
```bash
pkg update
pkg install python python-pip
pip install -r requirements.txt
