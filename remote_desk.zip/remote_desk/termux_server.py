from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
import time

# Initialize Flask app with SocketIO
app = Flask(__name__, static_folder='static')
app.config['SECRET_KEY'] = 'replace_this_with_a_real_secret'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# Store connected clients
agents = {}   # { sid: {"viewer": viewer_id, "last_frame": ...} }
viewers = {}  # { sid: {"agent": agent_id, "last_active": ...} }


@socketio.on('connect')
def handle_connect():
    print(f"Client connected: {request.sid}")


@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid

    # If it's an agent, clean up viewer too
    if sid in agents:
        viewer_id = agents[sid].get("viewer")
        if viewer_id and viewer_id in viewers:
            emit("agent_disconnected", room=viewer_id)
            del viewers[viewer_id]
        print(f"Agent disconnected: {sid}")
        del agents[sid]
        return

    # If it's a viewer, clean up agent mapping
    if sid in viewers:
        agent_id = viewers[sid].get("agent")
        if agent_id and agent_id in agents:
            agents[agent_id]["viewer"] = None
            emit("viewer_disconnected", room=agent_id)
        print(f"Viewer disconnected: {sid}")
        del viewers[sid]


@socketio.on('identify')
def handle_identity(data):
    role = data.get('role')
    if role == 'agent':
        agents[request.sid] = {"viewer": None, "last_frame": None}
        print(f"Agent registered: {request.sid}")
    elif role == 'viewer':
        viewers[request.sid] = {"agent": None, "last_active": time.time()}
        print(f"Viewer registered: {request.sid}")
    else:
        emit('error', {'message': 'Invalid role specified'})


@socketio.on('request_session')
def handle_session_request():
    """Viewer requests access to an agent"""
    if not agents:
        emit('error', {'message': 'No agents available'})
        return

    # Send session request to all agents
    emit('session_request', {'viewer_id': request.sid}, broadcast=True, include_self=False)
    print(f"Session requested by viewer: {request.sid}")


@socketio.on('session_response')
def handle_session_response(data):
    """Agent accepts or rejects session request"""
    accepted = data.get('accepted', False)
    viewer_id = data.get('viewer_id')

    if accepted and viewer_id in viewers:
        # Link agent and viewer
        agents[request.sid]["viewer"] = viewer_id
        viewers[viewer_id]["agent"] = request.sid

        # Notify both sides
        emit('session_accepted', room=viewer_id)
        emit('start_streaming', room=request.sid)
        print(f"Session accepted: Agent {request.sid} -> Viewer {viewer_id}")
    else:
        if viewer_id in viewers:
            emit('session_rejected', room=viewer_id)
        print(f"Session rejected for viewer: {viewer_id}")


@socketio.on('frame')
def handle_frame(data):
    """Receive frame from agent and forward to assigned viewer"""
    agent_id = request.sid
    frame_data = data.get('frame')

    if not frame_data:
        return

    # Save last frame (optional, useful if new viewer joins)
    agents[agent_id]["last_frame"] = frame_data

    viewer_id = agents[agent_id].get("viewer")
    if viewer_id and viewer_id in viewers:
        emit('frame', {'frame': frame_data}, room=viewer_id)


if __name__ == '__main__':
    print("Starting server on 0.0.0.0:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
