const socket = io();
let sessionActive = false;

// DOM elements
const requestBtn = document.getElementById('requestBtn');
const disconnectBtn = document.getElementById('disconnectBtn');
const statusDiv = document.getElementById('status');
const screenImg = document.getElementById('screen');

// Update status display
function updateStatus(connected, message) {
    statusDiv.textContent = message || (connected ? 'Connected' : 'Disconnected');
    statusDiv.className = 'status ' + (connected ? 'connected' : 'disconnected');
}

// Socket.IO events
socket.on('connect', () => {
    console.log('Connected to server');
    updateStatus(true, 'Connected to server');
    socket.emit('identify', { role: 'viewer' });
});

socket.on('disconnect', () => {
    console.log('Disconnected from server');
    updateStatus(false, 'Disconnected from server');
    sessionActive = false;
    updateUI();
});

socket.on('session_accepted', () => {
    console.log('Session accepted by agent');
    sessionActive = true;
    updateUI();
    updateStatus(true, 'Session active - streaming');
});

socket.on('session_rejected', () => {
    console.log('Session rejected by agent');
    alert('Session was rejected by the remote agent');
});

socket.on('frame', (data) => {
    screenImg.src = 'data:image/jpeg;base64,' + data.frame;
});

socket.on('error', (data) => {
    console.error('Error:', data.message);
    alert('Error: ' + data.message);
});

// UI event handlers
requestBtn.addEventListener('click', () => {
    socket.emit('request_session');
    updateStatus(true, 'Waiting for agent response...');
});

disconnectBtn.addEventListener('click', () => {
    socket.disconnect();
    location.reload(); // Simple refresh for now
});

// Update UI based on connection state
function updateUI() {
    requestBtn.disabled = sessionActive;
    disconnectBtn.disabled = !sessionActive;
}

// Initial UI setup
updateUI();
updateStatus(false);
